from __future__ import division
from hbp_nrp_excontrol.logs import clientLogger
from cv_bridge import CvBridge
from past.utils import old_div
import math
bridge = CvBridge()
@nrp.MapRobotSubscriber("camera", Topic('/icub_hbp_ros_0/icub_model/left_eye_camera/image_raw', sensor_msgs.msg.Image))
@nrp.MapVariable("initialized", initial_value=False)
@nrp.MapVariable("bridge", initial_value=bridge)
@nrp.MapVariable("frame_count", initial_value=0)
@nrp.MapVariable("previous_frame", initial_value=None)
@nrp.MapVariable("diff_sum", initial_value=0)
@nrp.MapVariable("n_samples", initial_value=0)
@nrp.MapSpikeSource("left_eye", nrp.brain.sensors[slice(0,2,1)], nrp.poisson)
@nrp.MapSpikeSource("right_eye", nrp.brain.sensors[slice(2,4,1)], nrp.poisson)

@nrp.Robot2Neuron()
def eye_sensor_transmit (t, initialized, bridge, camera, frame_count, previous_frame, diff_sum, n_samples, left_eye, right_eye):
    from past.utils import old_div
    import cv2
    import math
    import numpy as np
    tf = hbp_nrp_cle.tf_framework.tf_lib
    
    prepared_frame = None
    mean_stimulus_rate = 771 
    
    if camera.value is not None:
        img = bridge.value.imgmsg_to_cv2(camera.value, "rgb8")
        frame_count.value = frame_count.value + 1
        hsv_im = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        lower_np = np.array([50,100,100], dtype="uint8")
        upper_np = np.array([70,255,255], dtype="uint8")
        mask = cv2.inRange(hsv_im, lower_np, upper_np)
        #kernel = np.ones((2, 2))
        #mask = cv2.erode(mask, kernel)
        
        prepared_frame = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        
    if previous_frame.value is None:
        previous_frame.value = prepared_frame
        
    if (frame_count.value % 3)== 0:
        p0 = cv2.goodFeaturesToTrack(prepared_frame, mask=mask, maxCorners = 200, qualityLevel = 0.3, minDistance=0.01, blockSize=3)
        clientLogger.info 
        if p0 is not None and len(p0) > 150:
            p1, st, err = cv2.calcOpticalFlowPyrLK(previous_frame.value, prepared_frame, p0, None, winSize=(20,20), maxLevel=4, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03)) 
            good_new = p0[st==1]
            good_old = p1[st==1]
            diff = (good_new - good_old)
            n_dots = len(p1)
            h_dots = np.where(np.abs(diff[:,1]) < 1.5)
            still_dots = np.where(np.abs(diff[:,0]) < 0.5)
            n_h_dots = len(h_dots[0])
            avg = 0.0
            if (n_h_dots / n_dots) < 1.0:
                diff_sum.value = diff_sum.value + (n_h_dots / n_dots)
                n_samples.value = n_samples.value + 1
                avg = diff_sum.value / n_samples.value
                #clientLogger.info(f"Avg: {avg}")
                left_eye.rate = mean_stimulus_rate * (0.5 - (0.5 * avg))
                right_eye.rate = mean_stimulus_rate * (0.5 + (0.5 * avg))
            elif (len(still_dots[0]) / n_dots) > 0.9:
                
                #clientLogger.info("Stopping rates")
                left_eye.rate = 0.0
                right_eye.rate = 0.0
            else:
                diff_sum.value = 0
                n_samples.value = 0
        #if p0 is not None and len(p0) < 150:
            #left_eye.rate = 0.0
            #right_eye.rate = 0.0
         
            #clientLogger.info(f"Left eye rate: {left_eye.rate}")
            #clientLogger.info(f"Right eye rate: {right_eye.rate}")
            
        previous_frame.value = prepared_frame
        frame_count.value = frame_count.value + 1