import rospy
from gazebo_msgs.srv import SetModelState

rospy.wait_for_service("/gazebo/set_model_state")
service_proxy = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState, persistent=True)

@nrp.MapVariable("initial_pos", scope=nrp.GLOBAL)
@nrp.MapVariable("final_pos", scope=nrp.GLOBAL)
@nrp.MapVariable("direction", scope=nrp.GLOBAL)
@nrp.MapVariable("corr")
@nrp.MapVariable("speed", initial_value = 0.8)
@nrp.MapVariable("x_low", initial_value = -0.65)
@nrp.MapVariable("x_high", initial_value = 0.65)
@nrp.MapVariable("z_up", initial_value = 1.85)
@nrp.MapVariable("z_down", initial_value = 1.05)
@nrp.MapVariable("n_coherence", scope=nrp.GLOBAL)
@nrp.MapVariable("last_command_executed", initial_value=None)
@nrp.MapVariable("set_model_state_srv", initial_value=service_proxy)
@nrp.MapRobotSubscriber("command", Topic('/icub/commands', std_msgs.msg.String))

@nrp.Robot2Neuron() # dummy R2N
def move_target (t, speed, initial_pos, final_pos, direction, command,n_coherence, last_command_executed, corr, x_low, x_high, z_up, z_down, set_model_state_srv):
    import random
    if command.value is None:
        return
    else:
        command_str = command.value.data
    if command_str == "MOVE" and initial_pos.value is not None:
        n_targets = 50
        if last_command_executed.value!='MOVE':
            corr.value = [0.0 for i in range(0,n_targets,1)]
            for i in range(0,n_targets,1):
                corr.value[i] = t
        msgs_list = []
        for i in range(0,n_targets,1):
            p = Pose()
            p.orientation.x = 0
            p.orientation.y = 1
            p.orientation.z = 1
            p.position.x = initial_pos.value[i].x + (t-corr.value[i])*(direction.value[i].x)*speed.value
            p.position.y = initial_pos.value[i].y
            p.position.z = initial_pos.value[i].z + (t-corr.value[i])*(direction.value[i].z)*speed.value
            if p.position.x > x_high.value or p.position.x < x_low.value or p.position.z > z_up.value or p.position.z < z_down.value:
                if i < n_coherence.value:
                    initial_pos.value[i] = Point(x_low.value,initial_pos.value[i].y,random.uniform(z_down.value,z_up.value))
                else:
                    if final_pos.value[i].z == z_down.value:
                        z = z_up.value
                    elif final_pos.value[i].z == z_up.value:
                        z = z_down.value
                    initial_pos.value[i] = Point(random.uniform(x_low.value,x_high.value),initial_pos.value[i].y,z)
                p.position = initial_pos.value[i]
                corr.value[i] = t
            msg =  gazebo_msgs.msg.ModelState()
            msg.model_name = 'Target'+str(i)
            msg.pose = p
            msg.scale.x = msg.scale.y = msg.scale.z = 1.0
            msgs_list.append(msg)
        for msg in msgs_list:
            response = set_model_state_srv.value(msg)
    last_command_executed.value = command_str