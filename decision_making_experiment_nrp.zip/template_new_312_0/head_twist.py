from __future__ import division

# Imported Python Transfer Function
import hbp_nrp_cle.tf_framework as nrp
from hbp_nrp_cle.robotsim.RobotInterface import Topic
import std_msgs.msg
@nrp.MapSpikeSink("PopA", nrp.brain.actuators[slice(4,44,1)], nrp.population_rate)
@nrp.MapSpikeSink("PopB", nrp.brain.actuators[slice(44,84,1)], nrp.population_rate)
@nrp.Neuron2Robot(Topic('/icub_hbp_ros_0/eye_version/pos', std_msgs.msg.Float64))
def head_twist(t, PopA, PopB):
    from past.utils import old_div

    frequency_right=PopA.rate
    frequency_left=PopB.rate
    data=(50.0 * (frequency_right - frequency_left))
    if(data<50.0*200.0 and data>(-50.0*200.0)):
        data = 0
    # if abs(data)>0.3:
    #             sign=old_div(data,(abs(data)))
    #             data=0.3*sign
    #if rate maggiore di threshold -->
    return std_msgs.msg.Float64(data)
#