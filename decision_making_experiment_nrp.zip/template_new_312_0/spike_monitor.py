@nrp.NeuronMonitor(nrp.brain.circuit[slice(0,805,10)], nrp.spike_recorder)
def spike_monitor (t):
    return True