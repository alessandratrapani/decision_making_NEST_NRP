# Write brain script herefrom __future__ import division
from builtins import str
# pragma: no cover

import nest
import logging
import numpy
from hbp_nrp_cle.brainsim import simulator as sim
from hbp_nrp_excontrol.logs import clientLogger
import pyNN

__author__ = 'Group 2'

logger = logging.getLogger(__name__)

# Helper functions to automatically tune the network weights so to have near-threshold dynamics
def LambertWm1(x):
    return nest.ll_api.sli_func('LambertWm1', float(x))

def ComputePSPNorm(tau_mem, C_mem, tau_syn, is_NMDA=False):
    a = (tau_mem / tau_syn)
    if is_NMDA:
        a *= 5.02
    b = (1.0 / tau_syn -1.0 / tau_mem)
    t_max = 1.0 / b * (-LambertWm1(-numpy.exp(-1.0/a)/a) - 1.0 / a)
    return (numpy.exp(1.0) / (tau_syn * (C_mem * b) * 
            ((numpy.exp( -t_max / tau_mem) - numpy.exp(-t_max / tau_syn)) / b - 
            t_max * numpy.exp(-t_max / tau_syn))))


# --------------------------------
# Main function: 
# Returns the spiking circuit to be connected to the robotic agent
# --------------------------------
def create_brain():
    #dt = 1.0    # the resolution in ms
    simtime = 3000.0  # Simulation time in ms
    delay = 0.5    # Synaptic delay in ms
    delay_NMDA = 2.5
    
    eta_ex = 0.96  # External rate relative to threshold rate
    eta_in = 0.9
    epsilon_ex_recurrent = 0.6  # Connection probability between populations
    epsilon_in_recurrent = 0.5
    epsilon_ex_AI_BI = 0.6
    epsilon_in_IA_IB = 0.65
    epsilon_ex_AB_BA = 0.45

    order = 200 
    NA = 2 * order  # Number of excitatory neurons in pop A
    NB = 2 * order  # Number of excitatory neurons in pop A
    NI = 1 * order  # Number of inhibitory neurons
    N_neurons = NA + NB + NI   # Number of neurons in total
    
    nr_ports = 4  # Number of receptor types (noise-related, AMPA, NMDA, GABA)
    tau_syn = [5., 2., 100., 5.]  # Exponential time constant of post-synaptic current (PSC) for each receptor [ms]

    # Population-independent constants
    V_membrane = -70.0  # [mV] 
    V_threshold = -50.0  # [mV]
    V_reset = -55.0  # [mV]

    # Population-dependent constants
    # Excitatory
    C_m_ex = 500.0  # [pF]  
    # Inhibitory
    C_m_in = 200.0  # [pF]
    # Excitatory
    t_ref_ex = 2.0 
    # Inhibitory
    t_ref_in = 1.0
    # Excitatory
    tau_m_ex = 20.0
    # Inhibitory
    tau_m_in = 10.0

    # Storing the neurons' parameters in a dictionary to be assigned to the models later
    # Excitatory
    exc_neuron_params = {
        "E_L": V_membrane,
        "V_th": V_threshold,
        "V_reset": V_reset,
        "C_m": C_m_ex,  
        "tau_m": tau_m_ex,
        "t_ref": t_ref_ex, 
        "tau_syn": tau_syn
    }
    # Inhibitory 
    inh_neuron_params = {
        "E_L": V_membrane,
        "V_th": V_threshold,
        "V_reset": V_reset,
        "C_m": C_m_in, 
        "tau_m": tau_m_in,
        "t_ref": t_ref_in,
        "tau_syn": tau_syn 
    } 

    # Automatic weight tuning 
    J = 0.04  # Post-synaptic potential (PSP) induced by a single spike  [mV]  
    # Noise weights
    J_unit_noise = ComputePSPNorm(tau_m_ex, C_m_ex, tau_syn[0])
    J_norm_noise = J / J_unit_noise 
    # AMPA weights
    J_unit_AMPA = ComputePSPNorm(tau_m_ex, C_m_ex, tau_syn[1])
    J_norm_AMPA = J / J_unit_AMPA
    J_norm_AMPA = J_norm_AMPA 
    # NMDA weights
    J_norm_NMDA = 0.05  # the weight for the NMDA is set at 0.05, otherwise it would be 0
    # GABA weights
    J_unit_GABA = ComputePSPNorm(tau_m_in, C_m_in, tau_syn[3])
    J_norm_GABA = J / J_unit_GABA

    nu_th_noise_ex = (numpy.abs(V_threshold) * C_m_ex) / (J_norm_noise * numpy.exp(1) * tau_m_ex * tau_syn[0])
    nu_ex = eta_ex * nu_th_noise_ex
    p_rate = 1000.0 * nu_ex 
    clientLogger.info(p_rate)
    
    nu_th_noise_in = (numpy.abs(V_threshold) * C_m_in) / (J_norm_noise * numpy.exp(1) * tau_m_in * tau_syn[0])
    nu_in = eta_in * nu_th_noise_in
    p_rate_in = 1000.0 * nu_in
    clientLogger.info(p_rate_in)

    nest.SetDefaults("poisson_generator", {"rate": p_rate})    #poisson generator for the noise in input to popA and popB
    PG_noise = nest.Create("poisson_generator")

    nest.SetDefaults("poisson_generator", {"rate": p_rate_in})   #poisson generator for the noise in input to popinh
    PG_noise_to_inh = nest.Create("poisson_generator")


    #--------------------------------
    # Creating the nodes
    # --------------------------------
    # Defining the populations models and creating the nodes
    inputs = nest.Create("parrot_neuron", 4)  # Parrot neurons to transmit the inputs to the network, only act as separate buffers (one for each pop)   
    population = nest.Create("iaf_psc_exp_multisynapse", N_neurons)  # Instantiating a general (parameter-less) neuronal population (of current-based I&F) to model all the neurons
    nest.SetStatus(population[0: 4 * order - 1], exc_neuron_params)  # Defining the excitatory subpopulation numerosity and parameters
    nest.SetStatus(population[4 * order : 5 * order - 1], inh_neuron_params)  # Defining the inhibitory subpopulation numerosity and parameters

    # Defining the quantities to be used in the connectivity instructions
    # Subpopulation A and relative input  
    pop_A = population[0:(order * 2 -1)]  
    input_A_AMPA = inputs[0:1]
    input_A_NMDA = inputs[1:2]
   # input_noise_A= inputs[2:3]
    # Subpopulation B and relative input  
    pop_B = population[(order * 2) : order * 4 -1]
    input_B_AMPA = inputs[2:3]
    input_B_NMDA = inputs[3:4]
   # input_noise_B= inputs[5:6]
    # Subpopulation C and relative input  
    pop_inh = population[(order * 4) : (order * 5 -1)]
   # input_noise_inh= inputs[6:7]

    w_minus = 0.8
    w_plus = 1.7
    w_plus_NMDA = 4.25

    # Defining the synaptic connections names, parameters and receptor type to be used later
    nest.CopyModel("static_synapse", "excitatory_AMPA_AB_BA",
               {"weight": J_norm_AMPA*w_minus, "delay": delay})
    AMPA_syn_AB_BA= {"model": "excitatory_AMPA_AB_BA","receptor_type": 2}
    
    nest.CopyModel("static_synapse", "excitatory_NMDA_AB_BA",
                {"weight": J_norm_NMDA*w_minus, "delay": delay_NMDA})    
    NMDA_syn_AB_BA = {"model": "excitatory_NMDA_AB_BA","receptor_type": 3}
    
    nest.CopyModel("static_synapse", "excitatory_AMPA_AI_BI",
               {"weight": J_norm_AMPA*w_plus, "delay": delay})
    AMPA_syn_AI_BI= {"model": "excitatory_AMPA_AI_BI","receptor_type": 2}
    
    nest.CopyModel("static_synapse", "excitatory_NMDA_AI_BI",
                {"weight": J_norm_NMDA*w_plus, "delay": delay_NMDA})    
    NMDA_syn_AI_BI = {"model": "excitatory_NMDA_AI_BI","receptor_type": 3}
    
    nest.CopyModel("static_synapse", "inhibitory_IA_IB",
                   {"weight": -J_norm_GABA*w_plus, "delay": delay})  # the weight for the inhibitory connections to popA and popB is increased
    GABA_syn_IA_IB = {"model": "inhibitory_IA_IB","receptor_type": 4}
    
    nest.CopyModel("static_synapse", "excitatory_AMPA_recurrent",
               {"weight": J_norm_AMPA, "delay": delay})
    AMPA_syn_recurrent= {"model": "excitatory_AMPA_recurrent","receptor_type": 2}
    
    nest.CopyModel("static_synapse", "excitatory_NMDA_recurrent",
                {"weight": J_norm_NMDA*w_plus_NMDA, "delay": delay_NMDA})    
    NMDA_syn_recurrent = {"model": "excitatory_NMDA_recurrent","receptor_type": 3}
    
    nest.CopyModel("static_synapse", "inhibitory_recurrent",
                   {"weight": -J_norm_GABA, "delay": delay})  # the weight for the inhibitory connections to popA and popB is increased
    GABA_syn_recurrent = {"model": "inhibitory_recurrent","receptor_type": 4}   
    
    nest.CopyModel("static_synapse", "noise_syn",
                   {"weight": J_norm_noise, "delay": delay})  # the weight for the inhibitory connections to popA and popB is increased
    noise_syn = {"model": "noise_syn","receptor_type": 1}
    
    nest.CopyModel("static_synapse", "excitatory_AMPA_input",
                   {"weight": J_norm_AMPA, "delay": delay})  # the weight for the inhibitory connections to popA and popB is increased
    AMPA_input_syn = {"model": "excitatory_AMPA_input","receptor_type": 2}
    
    #--------------------------------
    # Connecting the nodes
    # -------------------------------

    # Defining the connectivty strategy to be used
    conn_params_ex_AB_BA = {'rule': 'pairwise_bernoulli', 'p': epsilon_ex_AB_BA}
    conn_params_ex_recurrent = {'rule': 'pairwise_bernoulli', 'p': epsilon_ex_recurrent}
    conn_params_ex_AI_BI = {'rule': 'pairwise_bernoulli', 'p': epsilon_ex_AI_BI}
    conn_params_in_IA_IB = {'rule': 'pairwise_bernoulli', 'p': epsilon_in_IA_IB}
    conn_params_in_recurrent = {'rule': 'pairwise_bernoulli', 'p': epsilon_in_recurrent}
    
    # Connecting the components

    #Noise
    nest.Connect(PG_noise, pop_A, syn_spec=noise_syn)
    nest.Connect(PG_noise, pop_B, syn_spec=noise_syn)
    nest.Connect(PG_noise_to_inh, pop_inh, syn_spec=noise_syn)
    

    #Input
    nest.Connect(input_A_AMPA, pop_A, syn_spec = AMPA_input_syn)
    nest.Connect(input_B_AMPA, pop_B, syn_spec = AMPA_input_syn)

    # Population A

    # Recurrent
    nest.Connect(pop_A, pop_A, conn_params_ex_recurrent, AMPA_syn_recurrent)
    nest.Connect(pop_A, pop_A, conn_params_ex_recurrent, NMDA_syn_recurrent)
    # To pop B
    nest.Connect(pop_A, pop_B, conn_params_ex_AB_BA, AMPA_syn_AB_BA)
    nest.Connect(pop_A, pop_B, conn_params_ex_AB_BA, NMDA_syn_AB_BA)
    # To pop inh.
    nest.Connect(pop_A, pop_inh, conn_params_ex_AI_BI, AMPA_syn_AI_BI)
    nest.Connect(pop_A, pop_inh, conn_params_ex_AI_BI, NMDA_syn_AI_BI)

    # Population B

    # Recurrent
    nest.Connect(pop_B, pop_B, conn_params_ex_recurrent, AMPA_syn_recurrent)
    nest.Connect(pop_B, pop_B, conn_params_ex_recurrent, NMDA_syn_recurrent)
    # To pop A
    nest.Connect(pop_B, pop_A, conn_params_ex_AB_BA, AMPA_syn_AB_BA)
    nest.Connect(pop_B, pop_A, conn_params_ex_AB_BA, NMDA_syn_AB_BA)
    # To pop inh.
    nest.Connect(pop_B, pop_inh, conn_params_ex_AI_BI, AMPA_syn_AI_BI)
    nest.Connect(pop_B, pop_inh, conn_params_ex_AI_BI, NMDA_syn_AI_BI)

    # Population inh 

    # Recurrent
    nest.Connect(pop_inh, pop_inh, conn_params_in_recurrent, GABA_syn_recurrent)
    # To pop A
    nest.Connect(pop_inh, pop_A, conn_params_in_IA_IB, GABA_syn_IA_IB)
    # To pop B
    nest.Connect(pop_inh, pop_B, conn_params_in_IA_IB, GABA_syn_IA_IB)


    #--------------------------------
    # End of function
    # -------------------------------
    # Finally, return the network composed by the sum of the two distinct node types (populations), 
    # the "input cells" and neuronal cells
    nodes = inputs + population
    return nodes

circuit = create_brain()