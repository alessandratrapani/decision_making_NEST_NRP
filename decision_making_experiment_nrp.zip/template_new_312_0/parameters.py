@nrp.MapVariable("initial_pos", scope=nrp.GLOBAL)
@nrp.MapVariable("final_pos", scope=nrp.GLOBAL)
@nrp.MapVariable("x_low", initial_value = -0.65)
@nrp.MapVariable("x_high", initial_value = 0.65)
@nrp.MapVariable("z_up", initial_value = 1.85)
@nrp.MapVariable("z_down", initial_value = 1.05)
@nrp.MapVariable("n_coherence", initial_value = 0, scope=nrp.GLOBAL)
@nrp.MapVariable("direction", scope=nrp.GLOBAL)
@nrp.MapRobotSubscriber("starting_pos", Topic('/icub/starting_pos', geometry_msgs.msg.PoseArray))
@nrp.MapVariable("last_command_executed", initial_value=None)
@nrp.MapRobotSubscriber("command", Topic('/icub/commands', std_msgs.msg.String))
@nrp.MapRobotSubscriber("coherence", Topic('/icub/coherence', std_msgs.msg.Int16))

@nrp.Robot2Neuron()
def parameters (t, initial_pos, final_pos, direction,coherence, n_coherence, x_low, x_high, z_up, z_down, starting_pos, last_command_executed, command):
    import random
    import numpy
    if command.value is None:
        return
    else:
        command_str = command.value.data
    if command_str == last_command_executed.value:
        return
    last_command_executed.value = command_str
    if command_str == "PARAMETERS":
        n_targets = 50
        initial_pos.value = [Point(0.,0.,0.) for i in range(0,n_targets,1)]
        final_pos.value = [Point(0.,0.,0.) for i in range(0,n_targets,1)]
        direction.value = [Point(0.,0.,0.) for i in range(0,n_targets,1)]
        coh = round(random.uniform(0.,1.),1)
        coh = 0.512
        n_coherence.value = int(coh*float(n_targets))
        clientLogger.info(n_coherence.value)
        for i in range(0,n_targets,1):
            initial_pos.value[i] = starting_pos.value.poses[i].position
            if i < n_coherence.value:
                final_pos.value[i] = Point(x_high.value, starting_pos.value.poses[i].position.y, starting_pos.value.poses[i].position.z)
            else:    
                final_pos.value[i] = Point(random.uniform(x_low.value,x_high.value), starting_pos.value.poses[i].position.y, random.choice([z_down.value, z_up.value]))
            array = np.array([final_pos.value[i].x-initial_pos.value[i].x, 0, final_pos.value[i].z-initial_pos.value[i].z])
            norm = numpy.linalg.norm(array)
            array = array/norm
            direction.value[i] = Point(array[0],array[1],array[2])