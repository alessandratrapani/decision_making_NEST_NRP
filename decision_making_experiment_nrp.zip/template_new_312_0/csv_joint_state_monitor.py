@nrp.MapRobotSubscriber("joints", Topic('/icub_hbp_ros_0/joints', sensor_msgs.msg.JointState))
@nrp.MapCSVRecorder("joints_recorder", filename="eye_joints_positions_03.csv", headers=["Time", "Position"])
@nrp.Robot2Neuron()
def csv_joint_state_monitor (t, joints, joints_recorder):
    joints = joints.value
    if not isinstance(joints, type(None)):
        joints_recorder.record_entry(t, joints.position[joints.name.index('eye_version')])