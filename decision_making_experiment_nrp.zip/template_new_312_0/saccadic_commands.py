from __future__ import division
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
@nrp.MapRobotSubscriber("joints", Topic("/icub_hbp_ros_0/joints", JointState))
@nrp.MapSpikeSink("left_movement_pop", nrp.brain.excitatory_pop[slice(0,400,1)], nrp.population_rate)
@nrp.MapSpikeSink("right_movement_pop", nrp.brain.excitatory_pop[slice(400,800,1)], nrp.population_rate)
@nrp.MapSpikeSink("pop_a_spikes", nrp.brain.excitatory_pop[slice(0,400,1)], nrp.spike_recorder)
@nrp.MapSpikeSink("pop_b_spikes", nrp.brain.excitatory_pop[slice(400,800,1)], nrp.spike_recorder)
@nrp.MapCSVRecorder("pop_a_spike_recorder", filename="spikes_A_51.csv", headers=["id", "time"])
@nrp.MapCSVRecorder("pop_b_spike_recorder", filename="spikes_B_51.csv", headers=["id", "time"])
@nrp.Neuron2Robot(Topic('/icub_hbp_ros_0/eye_version/pos', Float64))
def saccadic_commands (t, left_movement_pop, right_movement_pop, joints, pop_a_spikes, pop_b_spikes, pop_a_spike_recorder, pop_b_spike_recorder):
    from past.utils import old_div
    def deg2rad(deg):
        """
        Degrees to radians conversion function.
        :param deg: value in degrees
        :return: value of deg in radians
        """
        return (old_div(float(deg), 360.)) * (2. * np.pi)
    
    pop_a_rate = left_movement_pop.rate
    pop_b_rate = right_movement_pop.rate
    joints = joints.value
    ratio = pop_b_rate / pop_a_rate
    if joints is not None:
        eye_position = joints.position[joints.name.index('eye_version')]
    #clientLogger.info(pop_a_spikes.times)
    for entry in range(len(pop_a_spikes.times)):
        pop_a_spike_recorder.record_entry(
         pop_a_spikes.times[entry][0],
         pop_a_spikes.times[entry][1])
    for entry in range(len(pop_b_spikes.times)):
        pop_b_spike_recorder.record_entry(
         pop_b_spikes.times[entry][0],
         pop_b_spikes.times[entry][1])
    saccade = deg2rad(0.001 * (pop_a_rate - pop_b_rate))
    return saccade